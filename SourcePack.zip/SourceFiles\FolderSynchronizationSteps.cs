using System.IO;
using TechTalk.SpecFlow;
using NUnit.Framework;

namespace FolderSynchronizer.SpecFlowTests.StepDefinitions
{
    [Binding] // Marks this class as a SpecFlow step definition container
    public class FolderSynchronizationSteps
    {
        // -------------------------------------------------------------------------------------
        // This class defines BDD-style steps for testing folder synchronization using SpecFlow.
        //
        // It sets up the necessary source and replica folder paths, and runs the synchronization
        // using FolderSyncService.
        //
        // All folders are created under the project root: _SpecFlowTests_SourceFolder, etc.
        //
        // Supported scenarios from .feature file:
        //
        //  1. New file in source should be copied to replica
        //  2. Deleted file in replica should be added to replica from source
        //  3. Deleted file in source should be removed in replica
        //  4. Changed file content in source should be updated in replica
        // -------------------------------------------------------------------------------------

        private readonly string basePath;
        private readonly string sourcePath;
        private readonly string replicaPath;
        private readonly string logPath;
        private readonly string logFileName;
        private readonly string logFilePath;
        private string testFileName = string.Empty;

        public FolderSynchronizationSteps()
        {
            // Determine root path relative to bin/.../net6.0/
            basePath = Path.GetFullPath(Path.Combine(System.AppContext.BaseDirectory, @"..\..\..\..\..\"));

            // Define consistent test paths (under FolderSyncApp/)
            sourcePath = Path.Combine(basePath, "_SpecFlowTests_SourceFolder");
            replicaPath = Path.Combine(basePath, "_SpecFlowTests_ReplicaFolder");
            logPath = Path.Combine(basePath, "_TestsLogs");
            logFileName = "SpecFlowTests.log";
            logFilePath = Path.Combine(logPath, logFileName);

            // Create source folder if it doesn't exist
            if (!Directory.Exists(sourcePath)) Directory.CreateDirectory(sourcePath);

            // Create replica folder if it doesn't exist
            if (!Directory.Exists(replicaPath)) Directory.CreateDirectory(replicaPath);

            // Create log folder if it doesn't exist
            if (!Directory.Exists(logPath)) Directory.CreateDirectory(logPath);
        }

        [Given(@"the source folder contains a file named ""(.*)""")]
        public void GivenTheSourceFolderContainsAFile(string _fileName)
        {
            // Create a test file with dummy content in the source folder
            File.WriteAllText(Path.Combine(sourcePath, _fileName), "dummy content");

            // Save the file name for later verification
            testFileName = _fileName;
        }

        [Given(@"the replica folder contains a file named ""(.*)""")]
        public void GivenTheReplicaFolderContainsAFile(string _fileName)
        {
            // Create a file in the replica folder with placeholder content
            File.WriteAllText(Path.Combine(replicaPath, _fileName), "replica content");

            // Save the file name for later verification
            testFileName = _fileName;
        }

        [Given(@"the replica folder contains a file with name ""(.*)"" and content ""(.*)""")]
        public void GivenTheReplicaFolderContainsAFileWithContent(string _fileName, string _content)
        {
            // Create a file in the replica folder with specified content
            File.WriteAllText(Path.Combine(replicaPath, _fileName), _content);

            // Save the file name for later verification
            testFileName = _fileName;
        }

        [Given(@"the source folder contains a file with name ""(.*)"" and content ""(.*)""")]
        public void GivenTheSourceFolderContainsAFileWithContent(string _fileName, string _content)
        {
            // Create a file in the source folder with specified content
            File.WriteAllText(Path.Combine(sourcePath, _fileName), _content);

            // Save the file name for later verification
            testFileName = _fileName;
        }

        [Given(@"the source folder does not contain ""(.*)""")]
        public void GivenTheSourceFolderDoesNotContain(string _fileName)
        {
            // Delete file from source folder if it exists
            string fullPath = Path.Combine(sourcePath, _fileName);
            if (File.Exists(fullPath)) File.Delete(fullPath);
        }

        [Given(@"the replica folder does not contain ""(.*)""")]
        public void GivenTheReplicaFolderDoesNotContain(string _fileName)
        {
            // Delete file from replica folder if it exists
            string fullPath = Path.Combine(replicaPath, _fileName);
            if (File.Exists(fullPath)) File.Delete(fullPath);
        }

        [When(@"the folder synchronization runs")]
        public void WhenTheFolderSynchronizationRuns()
        {
            // Create synchronization service and run it once
            var sync = new FolderSynchronizer.FolderSyncService(sourcePath, replicaPath, logFilePath);
            sync.SynchronizeOnce();
        }

        [Then(@"the replica folder should contain the file ""(.*)""")]
        public void ThenTheReplicaFolderShouldContainTheFile(string _expectedFileName)
        {
            // Assert that the file exists in the replica folder
            string fullPath = Path.Combine(replicaPath, _expectedFileName);
            Assert.IsTrue(File.Exists(fullPath), $"Expected file {_expectedFileName} not found in replica.");
        }

        [Then(@"the file ""(.*)"" should not exist in the replica folder")]
        public void ThenTheFileShouldNotExistInTheReplicaFolder(string _fileName)
        {
            // Assert that the file does NOT exist in the replica folder
            string fullPath = Path.Combine(replicaPath, _fileName);
            Assert.IsFalse(File.Exists(fullPath), $"File {_fileName} was not removed from replica.");
        }

        [Then(@"the file ""(.*)"" in replica folder should contain ""(.*)""")]
        public void ThenTheFileInReplicaShouldContain(string _fileName, string _expectedContent)
        {
            // Assert that file exists in the replica folder
            string fullPath = Path.Combine(replicaPath, _fileName);
            Assert.IsTrue(File.Exists(fullPath), $"File {_fileName} does not exist in replica.");

            // Read the content of the replica file and assert it matches the expected content
            string actualContent = File.ReadAllText(fullPath);
            Assert.That(actualContent, Is.EqualTo(_expectedContent), $"Replica file {_fileName} content mismatch.");
        }
    }
}
