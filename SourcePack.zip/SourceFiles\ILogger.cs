using System;

namespace FolderSynchronizer
{
    // ---------------------------------------------------------------------------------------------
    // Interface for a simple logger abstraction
    // 
    // This interface defines basic logging functionality:
    //     - Info(...)  – for regular synchronization messages
    //     - Error(...) – for exception messages or errors
    //
    // It is used inside FolderSyncService and implemented by the Logger class.
    // ---------------------------------------------------------------------------------------------
    
    public interface ILogger
    {
        void Info(string _message);   // Logs regular information
        void Error(string _message);  // Logs errors
    }
}
