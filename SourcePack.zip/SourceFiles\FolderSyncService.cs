using System;
using System.IO;
using System.Security.Cryptography;
using System.Collections;

namespace FolderSynchronizer
{
    // ---------------------------------------------------------------------------------------------
    // FolderSyncService provides functionality to synchronize a source folder with a replica.
    //
    // Core operations:
    //     - CopyAll():     Recursively copies new or changed files from source to replica
    //     - DeleteRemovedFiles(): Removes files/folders from replica that no longer exist in source
    //     - FilesAreEqual(): Compares files using MD5 hash
    //
    //     SynchronizeOnce() combines both to perform a full one-pass sync
    //
    //     Logger is used to log all copy/update/delete operations and any errors.
    // ---------------------------------------------------------------------------------------------
    
    public class FolderSyncService
    {
        private readonly string sourcePath;
        private readonly string replicaPath;
        private readonly ILogger logger;

        // C-tor
        public FolderSyncService(string _sourcePath, string _replicaPath, string _logFileName, bool _quietMode = false)
        {
            this.sourcePath = _sourcePath;
            this.replicaPath = _replicaPath;
            this.logger = new Logger(_logFileName, _quietMode);
        }

        // Public method to run single synchronization pass (used in tests and CLI)
        public void SynchronizeOnce()
        {
            try
            {
                CopyAll(sourcePath, replicaPath);
                DeleteRemovedFiles(sourcePath, replicaPath);
            }
            catch (Exception ex)
            {
                logger.Error($"{ex.Message}");
            }
        }

        // Recursively copies files and directories from source to replica
        //
        // This method ensures that all content from the source directory is present in the replica directory.
        // It performs two main actions:
        //
        //   1. Copies all files from source to replica:
        //        - If the file doesn't exist in the replica, it is copied.
        //        - If it exists but the content is different (based on MD5 hash), it is overwritten.
        //        - Every copy/overwrite is logged.
        //
        //   2. Recursively processes subdirectories:
        //        - Each subdirectory from the source is mirrored into the replica.
        //        - The function calls itself for each nested directory (recursive call).
        //
        // Result:
        //   After execution, the replica will contain all files and folders that exist in the source,
        //   with up-to-date content.
        private void CopyAll(string _sourcePath, string _replicaPath)
        {
            // Ensure the replica directory exists
            Directory.CreateDirectory(_replicaPath);

            // Copy all files from source to replica
            foreach (string file in Directory.GetFiles(_sourcePath))
            {
                string targetFile = Path.Combine(_replicaPath, Path.GetFileName(file));
                if (!File.Exists(targetFile) || !FilesAreEqual(file, targetFile))
                {
                    File.Copy(file, targetFile, true);
                    logger.Info($"Copied/Updated: {targetFile}");
                }
            }

            // Recursively copy all subdirectories
            foreach (string dir in Directory.GetDirectories(_sourcePath))
            {
                CopyAll(dir, Path.Combine(_replicaPath, Path.GetFileName(dir)));
            }
        }

        // Deletes files and folders that no longer exist in the source
        //
        // This function compares the contents of the replica directory with the source directory,
        // and removes anything in the replica that does not exist in the source.
        //
        // There are two main loops:
        //   1. Files: Deletes files from replica that are missing in the source
        //   2. Directories: Recursively deletes folders missing in the source, and keeps checking subfolders
        private void DeleteRemovedFiles(string _sourcePath, string _replicaPath)
        {
            // Loop through all files in the replica directory
            foreach (string file in Directory.GetFiles(_replicaPath))
            {
                // Build expected path in the source for this file
                string sourceFile = Path.Combine(_sourcePath, Path.GetFileName(file));

                // If the file does not exist in source, delete it from replica
                if (!File.Exists(sourceFile))
                {
                    File.Delete(file);
                    logger.Info($"Deleted: {file}");
                }
            }

            // Loop through all directories in the replica
            foreach (string dir in Directory.GetDirectories(_replicaPath))
            {
                // Build expected path in the source for this directory
                string sourceSubDir = Path.Combine(_sourcePath, Path.GetFileName(dir));

                // If the directory does not exist in source, delete it from replica
                if (!Directory.Exists(sourceSubDir))
                {
                    Directory.Delete(dir, true); // 'true' to delete contents recursively
                    logger.Info($"Deleted folder: {dir}");
                }
                else
                {
                    // If the directory exists in both, check its contents recursively
                    DeleteRemovedFiles(sourceSubDir, dir);
                }
            }
        }

        // Compares two files by calculating their MD5 hashes
        private bool FilesAreEqual(string _file1, string _file2)
        {
            using (var md5 = MD5.Create())
            {
                using var stream1 = File.OpenRead(_file1);
                using var stream2 = File.OpenRead(_file2);
                var hash1 = md5.ComputeHash(stream1);
                var hash2 = md5.ComputeHash(stream2);
                return StructuralComparisons.StructuralEqualityComparer.Equals(hash1, hash2);
            }
        }
    }
}
