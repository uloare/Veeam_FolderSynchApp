// ----------------------------------------------------------------------------------------------------------
// UnitTestWithoutSpecFlow.cs
// ----------------------------------------------------------------------------------------------------------
// This file contains unit tests for the FolderSynchronizer logic, without using SpecFlow framework.
// Each test verifies a distinct synchronization scenario, using NUnit framework.
// All test folders and log files are created under FolderSyncApp root directory.
//
// Test scenarios:
// ----------------------------------------------------------------------------------------------------------
// UnitTest1_CopyNewCreatedFileFromSourceToReplica
//      - Verifies that a newly created file in the source folder is copied to the replica folder.
//
// UnitTest2_ChangedContentFileFromSourceToReplica
//      - Verifies that if the file already exists but has different content in source, it is updated in replica.
//
// UnitTest3_DeletedFileFromReplicaWillSynchronizeWithSource
//      - Verifies that if a file is deleted from replica but still exists in source, it is restored in replica.
//
// UnitTest4_DeletedFileFromSourceWillSynchronizeToReplica
//      - Verifies that if a file is deleted from source, it is also removed from replica.
//
// Notes:
//      - _quietMode: true is used when initializing FolderSyncService to suppress console output during test execution
//        and avoid misleading warnings in test output due to standard Console.WriteLine messages.
// ----------------------------------------------------------------------------------------------------------

using NUnit.Framework;
using System.IO;

namespace FolderSynchronizer.UnitTests
{
    [TestFixture]
    public class UnitTestWithoutSpecFlow
    {
        private string basePath;
        private string sourcePath;
        private string replicaPath;
        private string logPath;
        private string logFileName;
        private string logFilePath;

        [SetUp]
        public void Setup()
        {
            // Determine root path relative to bin/.../net6.0/
            basePath = Path.GetFullPath(Path.Combine(System.AppContext.BaseDirectory, @"..\..\..\..\..\"));            

            // Construct full paths under FolderSyncApp/
            sourcePath = Path.Combine(basePath, "_UnitTests_SourceFolder");
            replicaPath = Path.Combine(basePath, "_UnitTests_ReplicaFolder");
            logPath = Path.Combine(basePath, "_TestsLogs");
            logFileName = "UnitTests.log";
            logFilePath = Path.Combine(logPath, logFileName);

            // Create source folder if doesn't exists
            if (!Directory.Exists(sourcePath)) Directory.CreateDirectory(sourcePath);

            // Create replica folder if doesn't exists
            if (!Directory.Exists(replicaPath)) Directory.CreateDirectory(replicaPath);

            // Create log folder if doesn't exists
            if (!Directory.Exists(logPath)) Directory.CreateDirectory(logPath);
        }

        [Test]
        public void UnitTest1_CopyNewCreatedFileFromSourceToReplica()
        {
            // Create new test file in source folder
            string testFile = "UniTest_file1.txt";
            string content = "test content";
            string testFilePath = Path.Combine(sourcePath, testFile);
            File.WriteAllText(testFilePath, content);

            // Use quiet logger to avoid console output during test
            // _quietMode: true disables writing logs to Console during unit tests to prevent test runners from showing warnings
            var syncService = new FolderSynchronizer.FolderSyncService(sourcePath, replicaPath, logFilePath, _quietMode: true);

            // Synchronize folders
            syncService.SynchronizeOnce();

            // Assert - file exists in replica
            string copiedFilePath = Path.Combine(replicaPath, testFile);
            Assert.IsTrue(File.Exists(copiedFilePath), "File was not copied to the replica folder");

            // Assert - content is identical
            string copiedContent = File.ReadAllText(copiedFilePath);
            Assert.That(copiedContent, Is.EqualTo(content), "Copied file content does not match");

            // Assert - log file exists
            Assert.IsTrue(File.Exists(logFilePath), "Log file was not created");
        }

        [Test]
        public void UnitTest2_ChangedContentFileFromSourceToReplica()
        {
            // Change content in existing new test file in source folder
            string testFile = "UniTest_file1.txt";
            string content = "test content changed";
            string testFilePath = Path.Combine(sourcePath, testFile);
            File.WriteAllText(testFilePath, content);

            // Use quiet logger to avoid console output during test
            // _quietMode: true disables writing logs to Console during unit tests to prevent test runners from showing warnings            
            var syncService = new FolderSynchronizer.FolderSyncService(sourcePath, replicaPath, logFilePath, _quietMode: true);

            // Synchronize folders
            syncService.SynchronizeOnce();

            // Assert - file exists in replica
            string copiedFilePath = Path.Combine(replicaPath, testFile);
            Assert.IsTrue(File.Exists(copiedFilePath), "File was not copied to the replica folder");

            // Assert - content is identical
            string copiedContent = File.ReadAllText(copiedFilePath);
            Assert.That(copiedContent, Is.EqualTo(content), "Copied file content does not match");

            // Assert - log file exists 
            Assert.IsTrue(File.Exists(logFilePath), "Log file was not created");
        }

        [Test]
        public void UnitTest3_DeletedFileFromReplicaWillSynchronizeWithSource()
        {
            // Change content in existing new test file in source folder
            string testFile = "UniTest_file1.txt";
            string content = "test content changed"; // Content NOT changed from previous test
            string testFilePath = Path.Combine(replicaPath, testFile);

            // Remove the file from replica folder
            // Note:
            //  This file still exists in source folder
            File.Delete(testFilePath);

            // Assert - file exists in source
            string sourceFilePathBefore = Path.Combine(sourcePath, testFile);
            Assert.IsTrue(File.Exists(sourceFilePathBefore), "File was deleted from the source folder");

            // Assert - file NOT exists in replica
            string replicaFilePathBefore = Path.Combine(replicaPath, testFile);
            Assert.IsTrue(!File.Exists(replicaFilePathBefore), "File was not deleted from the replica folder");

            // Use quiet logger to avoid console output during test    
            // _quietMode: true disables writing logs to Console during unit tests to prevent test runners from showing warnings
            var syncService = new FolderSynchronizer.FolderSyncService(sourcePath, replicaPath, logFilePath, _quietMode: true);

            // Synchronize folders
            syncService.SynchronizeOnce();

            // Assert - file exists in source
            string sourceFilePath = Path.Combine(sourcePath, testFile);
            Assert.IsTrue(File.Exists(sourceFilePath), "File was deleted from the source folder");

            // Assert - file exists in replica
            string replicaFilePath = Path.Combine(replicaPath, testFile);
            Assert.IsTrue(File.Exists(replicaFilePath), "File was deleted from the replica folder");

            // Assert - content is identical
            string copiedContent = File.ReadAllText(replicaFilePath);
            Assert.That(copiedContent, Is.EqualTo(content), "Copied file content does not match");

            // Assert - log file exists 
            Assert.IsTrue(File.Exists(logFilePath), "Log file was not created");
        }

        [Test]
        public void UnitTest4_DeletedFileFromSourceWillSynchronizeToReplica()
        {
            // Change content in existing new test file in source folder
            string testFile = "UniTest_file1.txt";
            string testFilePath = Path.Combine(sourcePath, testFile);

            // Remove the file from source folder
            // Note:
            //  This file still exists in replica folder
            File.Delete(testFilePath);

            // Assert - file NOT exists in source
            string sourceFilePathBefore = Path.Combine(sourcePath, testFile);
            Assert.IsTrue(!File.Exists(sourceFilePathBefore), "File was NOT deleted from the source folder");

            // Assert - file exists in replica
            string replicaFilePathBefore = Path.Combine(replicaPath, testFile);
            Assert.IsTrue(File.Exists(replicaFilePathBefore), "File was deleted from the replica folder");

            // Use quiet logger to avoid console output during test     
            // _quietMode: true disables writing logs to Console during unit tests to prevent test runners from showing warnings
            var syncService = new FolderSynchronizer.FolderSyncService(sourcePath, replicaPath, logFilePath, _quietMode: true);

            // Synchronize folders
            syncService.SynchronizeOnce();

            // Assert - file NOT exists in source
            string sourceFilePath = Path.Combine(sourcePath, testFile);
            Assert.IsTrue(!File.Exists(sourceFilePath), "File was NOT deleted from the source folder");

            // Assert - file NOT exists in replica
            string replicaFilePath = Path.Combine(replicaPath, testFile);
            Assert.IsTrue(!File.Exists(replicaFilePath), "File was NOT deleted from the replica folder");

            // Assert - log file exists 
            Assert.IsTrue(File.Exists(logFilePath), "Log file was not created");
        }

        [TearDown]
        public void TearDown()
        {
            // Cleanup after tests is not used, just keep the history of folders and logs
        }
    }
}
