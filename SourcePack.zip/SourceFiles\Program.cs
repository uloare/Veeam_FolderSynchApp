using System;

namespace FolderSynchronizer
{
    class Program
    {
        static void Main(string[] args)
        {
            // ---------------------------------------------------------------------------------------------
            // Entry point for the FolderSynchronizer console application
            // 
            // Expected arguments:
            //      args[0] - Source folder path
            //      args[1] - Replica folder path
            //      args[2] - Synchronization interval in seconds
            //      args[3] - Log file name (will be stored in /logs folder)
            //
            // Example usage from CLI:
            //      dotnet run --project src/FolderSynchronizer -- "SourceFolder" "ReplicaFolder" 5 "log.txt"
            // ---------------------------------------------------------------------------------------------

            // Check if correct number of arguments was provided
            if (args.Length != 4)
            {
                Console.WriteLine("Usage: FolderSynchronizer <sourcePath> <replicaPath> <intervalSeconds> <logFilePath>");
                return;
            }

            // Read CLI arguments
            string sourcePath = args[0];
            string replicaPath = args[1];
            int intervalSeconds = int.Parse(args[2]);
            string logFilePath = args[3];

            // Initialize synchronization service
            var syncService = new FolderSyncService(sourcePath, replicaPath, logFilePath);

            // Run synchronization in an infinite loop every N seconds
            while (true)
            {
                syncService.SynchronizeOnce();
                System.Threading.Thread.Sleep(intervalSeconds * 1000);
            }
        }
    }
}
