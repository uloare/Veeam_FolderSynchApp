using System;
using System.IO;

namespace FolderSynchronizer
{
    // ---------------------------------------------------------------------------------------------
    // Logger implements ILogger to provide logging functionality for synchronization operations.
    //
    // It writes log entries to a file inside the "_TestsLogs" folder, and optionally outputs them
    // to the console (unless quietMode is enabled).
    //
    //  quietMode: 
    //      - Used during unit testing to suppress console output.
    //      - Prevents warnings from dotnet test runner about unexpected console messages.
    // ---------------------------------------------------------------------------------------------
    
    public class Logger : ILogger
    {
        // Log constant directory name (folder is relative to app root)
        const string logDirectory = "_TestsLogs";

        // Log file path – full path built from log directory and filename
        private readonly string logFilePath;

        // Quiet mode disables console output (useful for tests)
        private readonly bool quietMode;

        // Constructor
        public Logger(string _logFileName, bool _quietMode = false)
        {
            logFilePath = Path.Combine(logDirectory, _logFileName);
            quietMode = _quietMode;
        }

        // Logs an informational message (e.g., file copied, deleted, updated).
        public void Info(string _message)
        {
            string logEntry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] INFO: {_message}";

            if (!quietMode)
                Console.WriteLine(logEntry);

            EnsureLogDirectoryExists();
            File.AppendAllText(logFilePath, logEntry + Environment.NewLine);
        }

        // Logs an error message (e.g., exceptions, issues during synchronization).
        public void Error(string _message)
        {
            string logEntry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] ERROR: {_message}";

            if (!quietMode)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(logEntry);
                Console.ResetColor();
            }

            EnsureLogDirectoryExists();
            File.AppendAllText(logFilePath, logEntry + Environment.NewLine);
        }

        // Ensures that the folder for logs exists before writing the log file.
        private void EnsureLogDirectoryExists()
        {
            string? directory = Path.GetDirectoryName(logFilePath);
            if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }
        }
    }
}
